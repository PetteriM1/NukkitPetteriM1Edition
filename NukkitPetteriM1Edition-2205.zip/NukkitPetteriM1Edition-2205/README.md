# Nukkit PetteriM1 Edition
This is a custom version of [Nukkit](https://github.com/CloudburstMC/Nukkit) Minecraft Bedrock Edition server software made for my server [SuomiCraft PE](https://suomicraft-pe.tk/).

See the [wiki](https://github.com/PetteriM1/NukkitPetteriM1Edition/wiki) for more details.

<!--NOTE: The code in this repository is very outdated and should not be used. Download the latest build of Nukkit PM1E from releases.-->

>[Download](https://github.com/PetteriM1/NukkitPetteriM1Edition/releases)
